
import React from "react";

export default function App() {
  const handlePurchase = async (amount) => {
    const response = await fetch("https://sandboxapi.bitnob.co/api/v1/virtualcards/create", {
      method: "POST",
      headers: {
        "Authorization": "Bearer YOUR_API_KEY",
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        customerEmail: "abc@gmail.com",
        firstName: "Nana",
        lastName: "Mends",
        cardBrand: "mastercard",
        cardType: "giftcard",
        amount: amount,
        reference: `ref-${Date.now()}`
      })
    });

    const data = await response.json();
    if (data.status) {
      alert("Card created successfully!");
    } else {
      alert("Failed to create card.");
    }
  };

  return (
    <div style={{ backgroundColor: 'black', color: 'white', minHeight: '100vh', padding: '20px' }}>
      <h1 style={{ color: '#39ff14', fontSize: '32px', fontWeight: 'bold' }}>
        Get Your Virtual Visa Card Instantly
      </h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px', marginTop: '20px' }}>
        {[100, 200, 300, 400, 500].map((amount, index) => (
          <div key={index} style={{ backgroundColor: '#1f1f1f', padding: '20px', border: '1px solid #39ff14', borderRadius: '8px' }}>
            <h2 style={{ fontSize: '24px' }}>Visa Card - ${amount}</h2>
            <p style={{ fontSize: '14px', marginTop: '10px' }}>Use online globally. Instant delivery.</p>
            <button
              style={{ marginTop: '20px', width: '100%', backgroundColor: '#39ff14', color: 'black', padding: '10px', borderRadius: '5px' }}
              onClick={() => handlePurchase(amount)}
            >
              Buy Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
