
import { useEffect, useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BadgeDollarSign } from "lucide-react";

export default function Home() {
  const [cards, setCards] = useState([]);

  useEffect(() => {
    fetch('/api/cards')
      .then(res => res.json())
      .then(data => setCards(data.cards))
      .catch(err => console.error("خطأ في تحميل الكروت:", err));
  }, []);

  return (
    <main className="min-h-screen bg-black text-green-400 font-mono p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Bitnob Virtual Cards</h1>
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card, index) => (
          <Card key={index} className="bg-zinc-900 border border-green-600 rounded-2xl shadow-md">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{card.card_last_four ? `**** **** **** ${card.card_last_four}` : "Card"}</h2>
              <p>Status: <span className="font-bold">{card.status}</span></p>
              <p>Type: {card.card_type}</p>
              <p>Currency: {card.currency}</p>
            </CardContent>
          </Card>
        ))}
      </section>
    </main>
  );
}
