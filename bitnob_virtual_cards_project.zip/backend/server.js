
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3001;

let cardsDB = []; // قاعدة بيانات وهمية في الذاكرة

app.use(cors());
app.use(bodyParser.json());

// Webhook Endpoint من Bitnob
app.post('/webhook/bitnob', (req, res) => {
  const event = req.body;
  console.log("تم استقبال حدث من Bitnob:", event.event);

  if (event.event === 'virtual.card.created' || event.event === 'virtual.card.updated') {
    const data = event.data;
    const existingIndex = cardsDB.findIndex(c => c.id === data.id);

    if (existingIndex > -1) {
      cardsDB[existingIndex] = { ...cardsDB[existingIndex], ...data };
    } else {
      cardsDB.push(data);
    }
  }

  res.status(200).send('تم الاستلام');
});

// Endpoint للواجهة
app.get('/api/cards', (req, res) => {
  res.json({ cards: cardsDB });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
